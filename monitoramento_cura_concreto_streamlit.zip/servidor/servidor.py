# ============================================================
# SERVIDOR FASTAPI
# ============================================================


from fastapi import FastAPI, HTTPException

from .modelos import Leitura
from .banco import (
    criar_banco,
    salvar_leitura,
    buscar_leituras
)


app = FastAPI(
    title="Servidor de Monitoramento da Cura do Concreto",
    description=(
        "API para recebimento dos dados "
        "dos sensores de temperatura e umidade."
    ),
    version="1.0.0"
)


@app.on_event("startup")
def startup():

    criar_banco()

    print(
        "Banco de dados inicializado."
    )


@app.get("/")
def inicio():

    return {
        "sistema":
            "Monitoramento da Cura do Concreto",

        "status":
            "online",

        "servico":
            "FastAPI"
    }


@app.get("/status")
def status():

    leituras = buscar_leituras(
        limite=1
    )

    if not leituras:

        return {
            "status": "online",
            "ultima_leitura": None
        }

    return {
        "status": "online",
        "ultima_leitura":
            leituras[0]["timestamp"]
    }


@app.post("/dados")
def receber_dados(
    leitura: Leitura
):

    try:

        dados = leitura.model_dump()

        salvar_leitura(
            dados
        )

        return {

            "status":
                "sucesso",

            "mensagem":
                "Dados recebidos e armazenados.",

            "timestamp":
                dados["timestamp"]
        }

    except Exception as erro:

        raise HTTPException(
            status_code=500,
            detail=str(erro)
        )


@app.get("/dados")
def obter_dados(
    limite: int = 1000
):

    if limite < 1:

        limite = 1

    if limite > 10000:

        limite = 10000

    return buscar_leituras(
        limite
    )