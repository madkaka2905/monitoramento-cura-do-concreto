# ============================================================
# MODELOS DOS DADOS
# ============================================================

from pydantic import BaseModel, Field
from typing import Dict


class BME280(BaseModel):

    temperatura: float = Field(
        ...,
        description="Temperatura em °C"
    )

    umidade: float = Field(
        ...,
        ge=0,
        le=100,
        description="Umidade relativa em %"
    )

    pressao: float = Field(
        ...,
        description="Pressão atmosférica em hPa"
    )


class Leitura(BaseModel):

    cliente_id: str

    timestamp: str

    temperatura: Dict[str, float]

    umidade_solo: Dict[str, float]

    bme280: BME280