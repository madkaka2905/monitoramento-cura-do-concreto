# ============================================================
# BANCO DE DADOS E ARMAZENAMENTO
# ============================================================

import sqlite3
import csv
import json
import os
from datetime import datetime


BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

DADOS_DIR = os.path.join(
    BASE_DIR,
    "dados"
)

CSV_DIR = os.path.join(
    DADOS_DIR,
    "csv"
)

DB_PATH = os.path.join(
    DADOS_DIR,
    "monitoramento.db"
)


def criar_diretorios():

    os.makedirs(
        CSV_DIR,
        exist_ok=True
    )


def conectar():

    criar_diretorios()

    return sqlite3.connect(
        DB_PATH
    )


def criar_banco():

    conexao = conectar()

    cursor = conexao.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS leituras (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            cliente_id TEXT NOT NULL,

            timestamp TEXT NOT NULL,

            ds18b20_1 REAL,
            ds18b20_2 REAL,
            ds18b20_3 REAL,
            ds18b20_4 REAL,

            solo_1 REAL,
            solo_2 REAL,
            solo_3 REAL,
            solo_4 REAL,

            bme280_temperatura REAL,
            bme280_umidade REAL,
            bme280_pressao REAL,

            dados_json TEXT
        )
    """)

    conexao.commit()

    conexao.close()


def salvar_leitura(dados):

    criar_banco()

    timestamp = datetime.fromisoformat(
        dados["timestamp"]
    )

    conexao = conectar()

    cursor = conexao.cursor()

    temperaturas = dados["temperatura"]

    umidades = dados["umidade_solo"]

    bme = dados["bme280"]

    cursor.execute("""
        INSERT INTO leituras (

            cliente_id,
            timestamp,

            ds18b20_1,
            ds18b20_2,
            ds18b20_3,
            ds18b20_4,

            solo_1,
            solo_2,
            solo_3,
            solo_4,

            bme280_temperatura,
            bme280_umidade,
            bme280_pressao,

            dados_json

        )

        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (

        dados["cliente_id"],
        dados["timestamp"],

        temperaturas.get("ds18b20_1"),
        temperaturas.get("ds18b20_2"),
        temperaturas.get("ds18b20_3"),
        temperaturas.get("ds18b20_4"),

        umidades.get("sensor_1"),
        umidades.get("sensor_2"),
        umidades.get("sensor_3"),
        umidades.get("sensor_4"),

        bme["temperatura"],
        bme["umidade"],
        bme["pressao"],

        json.dumps(dados)
    ))

    conexao.commit()

    conexao.close()

    salvar_csv(
        dados,
        timestamp
    )


def salvar_csv(dados, timestamp):

    ano = timestamp.strftime("%Y")
    mes = timestamp.strftime("%m")
    dia = timestamp.strftime("%d")

    pasta = os.path.join(
        CSV_DIR,
        ano,
        mes,
        dia
    )

    os.makedirs(
        pasta,
        exist_ok=True
    )

    arquivo = os.path.join(
        pasta,
        "leituras.csv"
    )

    arquivo_existe = os.path.exists(
        arquivo
    )

    linha = {

        "timestamp":
            dados["timestamp"],

        "cliente_id":
            dados["cliente_id"],

        "ds18b20_1":
            dados["temperatura"]["ds18b20_1"],

        "ds18b20_2":
            dados["temperatura"]["ds18b20_2"],

        "ds18b20_3":
            dados["temperatura"]["ds18b20_3"],

        "ds18b20_4":
            dados["temperatura"]["ds18b20_4"],

        "solo_1":
            dados["umidade_solo"]["sensor_1"],

        "solo_2":
            dados["umidade_solo"]["sensor_2"],

        "solo_3":
            dados["umidade_solo"]["sensor_3"],

        "solo_4":
            dados["umidade_solo"]["sensor_4"],

        "bme280_temperatura":
            dados["bme280"]["temperatura"],

        "bme280_umidade":
            dados["bme280"]["umidade"],

        "bme280_pressao":
            dados["bme280"]["pressao"]
    }

    with open(
        arquivo,
        "a",
        newline="",
        encoding="utf-8"
    ) as f:

        writer = csv.DictWriter(
            f,
            fieldnames=linha.keys()
        )

        if not arquivo_existe:

            writer.writeheader()

        writer.writerow(linha)


def buscar_leituras(limite=1000):

    criar_banco()

    conexao = conectar()

    conexao.row_factory = sqlite3.Row

    cursor = conexao.cursor()

    cursor.execute("""
        SELECT *
        FROM leituras
        ORDER BY timestamp DESC
        LIMIT ?
    """, (limite,))

    resultados = cursor.fetchall()

    conexao.close()

    return [
        dict(row)
        for row in resultados
    ]