# Monitoramento da Cura do Concreto — publicação

Projeto preparado para publicação no Streamlit Community Cloud.

## Arquivo principal detectado
`dashboard/app.py`

## Publicar
1. Crie um repositório no GitHub.
2. Envie **todo o conteúdo desta pasta** para o repositório.
3. Acesse o Streamlit Community Cloud e faça login com o GitHub.
4. Escolha o repositório, a branch e o arquivo principal:
   `dashboard/app.py`
5. Clique em Deploy.
6. O Streamlit fornecerá um link público `*.streamlit.app`.

## Dependências
O `requirements.txt` foi preparado/atualizado para incluir as dependências detectadas.

## Observação
Se o projeto depender de arquivos locais (CSV, Excel, imagens ou banco SQLite), mantenha esses arquivos dentro do repositório e use caminhos relativos ao projeto.
