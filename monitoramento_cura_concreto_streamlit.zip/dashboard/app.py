# ============================================================
# DASHBOARD STREAMLIT
# ============================================================

import streamlit as st
import pandas as pd
import requests
import plotly.graph_objects as go
import numpy as np

from datetime import datetime


# ============================================================
# CONFIGURAÇÃO
# ============================================================

st.set_page_config(
    page_title="Monitoramento da Cura do Concreto",
    page_icon="🏗️",
    layout="wide"
)


SERVIDOR_URL = "http://127.0.0.1:8000"


# ============================================================
# FUNÇÕES
# ============================================================

def obter_dados():

    try:

        resposta = requests.get(
            f"{SERVIDOR_URL}/dados",
            params={
                "limite": 5000
            },
            timeout=5
        )

        resposta.raise_for_status()

        dados = resposta.json()

        if not dados:

            return pd.DataFrame()

        return pd.DataFrame(dados)

    except Exception as erro:

        st.error(
            f"Erro ao conectar ao servidor: {erro}"
        )

        return pd.DataFrame()


def preparar_dataframe(df):

    if df.empty:

        return df

    df["timestamp"] = pd.to_datetime(
        df["timestamp"]
    )

    df = df.sort_values(
        "timestamp"
    )

    return df


# ============================================================
# TÍTULO
# ============================================================

st.title(
    "🏗️ Monitoramento da Cura do Concreto"
)

st.caption(
    "Sistema de monitoramento de temperatura e umidade"
)


# ============================================================
# DADOS
# ============================================================

df = obter_dados()

df = preparar_dataframe(df)


if df.empty:

    st.warning(
        "Ainda não existem dados recebidos."
    )

    st.info(
        "Execute o servidor e depois o cliente."
    )

    st.stop()


# ============================================================
# ÚLTIMA LEITURA
# ============================================================

ultima = df.iloc[-1]


st.subheader(
    "📡 Última leitura"
)


col1, col2, col3, col4 = st.columns(4)


with col1:

    st.metric(
        "DS18B20 #1",
        f"{ultima['ds18b20_1']:.2f} °C"
    )


with col2:

    st.metric(
        "DS18B20 #2",
        f"{ultima['ds18b20_2']:.2f} °C"
    )


with col3:

    st.metric(
        "DS18B20 #3",
        f"{ultima['ds18b20_3']:.2f} °C"
    )


with col4:

    st.metric(
        "DS18B20 #4",
        f"{ultima['ds18b20_4']:.2f} °C"
    )


col1, col2, col3, col4 = st.columns(4)


with col1:

    st.metric(
        "Umidade solo #1",
        f"{ultima['solo_1']:.1f} %"
    )


with col2:

    st.metric(
        "Umidade solo #2",
        f"{ultima['solo_2']:.1f} %"
    )


with col3:

    st.metric(
        "Umidade solo #3",
        f"{ultima['solo_3']:.1f} %"
    )


with col4:

    st.metric(
        "Umidade solo #4",
        f"{ultima['solo_4']:.1f} %"
    )


# ============================================================
# BME280
# ============================================================

st.subheader(
    "🌡️ BME280"
)


col1, col2, col3 = st.columns(3)


with col1:

    st.metric(
        "Temperatura",
        f"{ultima['bme280_temperatura']:.2f} °C"
    )


with col2:

    st.metric(
        "Umidade",
        f"{ultima['bme280_umidade']:.1f} %"
    )


with col3:

    st.metric(
        "Pressão",
        f"{ultima['bme280_pressao']:.1f} hPa"
    )


# ============================================================
# GRÁFICO 2D - TEMPERATURA
# ============================================================

st.subheader(
    "📈 Temperatura dos sensores"
)


fig_temp = go.Figure()


for i in range(1, 5):

    coluna = f"ds18b20_{i}"

    fig_temp.add_trace(
        go.Scatter(
            x=df["timestamp"],
            y=df[coluna],
            mode="lines",
            name=f"DS18B20 #{i}"
        )
    )


fig_temp.add_trace(
    go.Scatter(
        x=df["timestamp"],
        y=df["bme280_temperatura"],
        mode="lines",
        name="BME280"
    )
)


fig_temp.update_layout(
    xaxis_title="Data/Hora",
    yaxis_title="Temperatura (°C)",
    hovermode="x unified",
    height=500
)


st.plotly_chart(
    fig_temp,
    use_container_width=True
)


# ============================================================
# GRÁFICO 2D - UMIDADE
# ============================================================

st.subheader(
    "💧 Umidade dos sensores de solo"
)


fig_umidade = go.Figure()


for i in range(1, 5):

    coluna = f"solo_{i}"

    fig_umidade.add_trace(
        go.Scatter(
            x=df["timestamp"],
            y=df[coluna],
            mode="lines",
            name=f"Solo #{i}"
        )
    )


fig_umidade.add_trace(
    go.Scatter(
        x=df["timestamp"],
        y=df["bme280_umidade"],
        mode="lines",
        name="BME280"
    )
)


fig_umidade.update_layout(
    xaxis_title="Data/Hora",
    yaxis_title="Umidade (%)",
    hovermode="x unified",
    height=500
)


st.plotly_chart(
    fig_umidade,
    use_container_width=True
)


# ============================================================
# GRÁFICO 3D
# ============================================================

st.subheader(
    "📦 Distribuição dos sensores dentro da caixa"
)


# Posições ilustrativas dos sensores
posicoes = {

    "DS18B20 #1": (0, 0, 0),
    "DS18B20 #2": (1, 0, 0.5),
    "DS18B20 #3": (0, 1, 1),
    "DS18B20 #4": (1, 1, 0.2),

}


temperaturas_3d = [

    ultima["ds18b20_1"],
    ultima["ds18b20_2"],
    ultima["ds18b20_3"],
    ultima["ds18b20_4"]

]


x = [
    posicoes[nome][0]
    for nome in posicoes
]

y = [
    posicoes[nome][1]
    for nome in posicoes
]

z = [
    posicoes[nome][2]
    for nome in posicoes
]


fig_3d = go.Figure()


fig_3d.add_trace(
    go.Scatter3d(

        x=x,
        y=y,
        z=z,

        mode="markers+text",

        text=list(
            posicoes.keys()
        ),

        textposition="top center",

        marker=dict(
            size=12,
            color=temperaturas_3d,
            colorscale="Turbo",
            colorbar=dict(
                title="°C"
            )
        )
    )
)


fig_3d.update_layout(

    scene=dict(

        xaxis_title="X",

        yaxis_title="Y",

        zaxis_title="Profundidade"
    ),

    height=650
)


st.plotly_chart(
    fig_3d,
    use_container_width=True
)


# ============================================================
# TABELA
# ============================================================

st.subheader(
    "📋 Dados recebidos"
)


colunas = [

    "timestamp",
    "cliente_id",

    "ds18b20_1",
    "ds18b20_2",
    "ds18b20_3",
    "ds18b20_4",

    "solo_1",
    "solo_2",
    "solo_3",
    "solo_4",

    "bme280_temperatura",
    "bme280_umidade",
    "bme280_pressao"

]


st.dataframe(
    df[colunas].sort_values(
        "timestamp",
        ascending=False
    ),
    use_container_width=True
)


# ============================================================
# DOWNLOAD CSV
# ============================================================

st.subheader(
    "💾 Exportação"
)


csv = df.to_csv(
    index=False
).encode(
    "utf-8"
)


st.download_button(
    label="Baixar dados em CSV",
    data=csv,
    file_name="monitoramento_cura_concreto.csv",
    mime="text/csv"
)


# ============================================================
# INFORMAÇÕES
# ============================================================

st.sidebar.title(
    "⚙️ Sistema"
)

st.sidebar.write(
    f"Servidor: {SERVIDOR_URL}"
)

st.sidebar.write(
    f"Registros carregados: {len(df)}"
)

st.sidebar.write(
    f"Última atualização: "
    f"{ultima['timestamp']}"
)