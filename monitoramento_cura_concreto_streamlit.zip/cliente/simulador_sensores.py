# ============================================================
# SIMULADOR DOS SENSORES
# ============================================================

import random
from datetime import datetime


class SimuladorSensores:

    def __init__(self):
        # Temperaturas iniciais dos 4 DS18B20
        self.temperaturas = [
            28.0,
            28.5,
            29.0,
            28.3
        ]

        # Umidades iniciais dos 4 sensores de solo
        self.umidades_solo = [
            72.0,
            68.0,
            75.0,
            70.0
        ]

        # Dados iniciais do BME280
        self.temperatura_bme = 28.5
        self.umidade_bme = 74.0
        self.pressao_bme = 1013.0

    def variar_valor(self, valor, variacao, minimo, maximo):
        """
        Altera suavemente um valor.
        """

        novo_valor = valor + random.uniform(
            -variacao,
            variacao
        )

        novo_valor = max(minimo, novo_valor)
        novo_valor = min(maximo, novo_valor)

        return novo_valor

    def ler_ds18b20(self):
        """
        Simula os 4 sensores DS18B20.
        """

        for i in range(4):

            self.temperaturas[i] = self.variar_valor(
                self.temperaturas[i],
                0.25,
                15,
                45
            )

        return {
            f"ds18b20_{i + 1}": round(
                self.temperaturas[i],
                2
            )
            for i in range(4)
        }

    def ler_umidade_solo(self):
        """
        Simula os 4 sensores de umidade do solo.
        """

        for i in range(4):

            self.umidades_solo[i] = self.variar_valor(
                self.umidades_solo[i],
                1.5,
                0,
                100
            )

        return {
            f"sensor_{i + 1}": round(
                self.umidades_solo[i],
                2
            )
            for i in range(4)
        }

    def ler_bme280(self):
        """
        Simula o BME280.
        """

        self.temperatura_bme = self.variar_valor(
            self.temperatura_bme,
            0.2,
            15,
            45
        )

        self.umidade_bme = self.variar_valor(
            self.umidade_bme,
            1.0,
            0,
            100
        )

        self.pressao_bme = self.variar_valor(
            self.pressao_bme,
            0.8,
            950,
            1050
        )

        return {
            "temperatura": round(
                self.temperatura_bme,
                2
            ),
            "umidade": round(
                self.umidade_bme,
                2
            ),
            "pressao": round(
                self.pressao_bme,
                2
            )
        }

    def gerar_leitura(self, cliente_id):
        """
        Gera uma leitura completa.
        """

        return {
            "cliente_id": cliente_id,

            "timestamp": datetime.now().isoformat(),

            "temperatura": self.ler_ds18b20(),

            "umidade_solo": self.ler_umidade_solo(),

            "bme280": self.ler_bme280()
        }