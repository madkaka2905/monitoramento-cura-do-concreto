# ============================================================
# CONFIGURAÇÕES DO CLIENTE
# ============================================================

# Endereço IP do computador onde o servidor FastAPI estará rodando.
# Se servidor e cliente estiverem no mesmo computador:
SERVIDOR_URL = "http://127.0.0.1:8000"

# Se estiverem em computadores diferentes, coloque o IP do servidor.
# Exemplo:
# SERVIDOR_URL = "http://192.168.0.100:8000"

ENDPOINT_DADOS = f"{SERVIDOR_URL}/dados"

# Intervalo entre cada envio, em segundos.
INTERVALO_ENVIO = 5

# Identificação desse cliente
CLIENTE_ID = "arduino_simulado_01"

# Timeout da comunicação
TIMEOUT = 10