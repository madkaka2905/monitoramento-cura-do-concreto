# ============================================================
# CLIENTE - SIMULADOR DO ARDUINO
# ============================================================

import time
import requests

from simulador_sensores import SimuladorSensores
from config import (
    ENDPOINT_DADOS,
    INTERVALO_ENVIO,
    CLIENTE_ID,
    TIMEOUT
)


def enviar_dados(dados):

    try:

        resposta = requests.post(
            ENDPOINT_DADOS,
            json=dados,
            timeout=TIMEOUT
        )

        if resposta.status_code == 200:

            print(
                f"[OK] Dados enviados | "
                f"{dados['timestamp']}"
            )

        else:

            print(
                f"[ERRO] Servidor respondeu "
                f"{resposta.status_code}"
            )

            print(resposta.text)

    except requests.exceptions.ConnectionError:

        print(
            "[ERRO] Não foi possível conectar "
            "ao servidor."
        )

    except requests.exceptions.Timeout:

        print(
            "[ERRO] Tempo limite de conexão "
            "excedido."
        )

    except Exception as erro:

        print(
            f"[ERRO] {erro}"
        )


def main():

    print("=" * 60)
    print("CLIENTE - SIMULADOR DO ARDUINO")
    print("=" * 60)

    print(f"Servidor: {ENDPOINT_DADOS}")
    print(f"Cliente: {CLIENTE_ID}")
    print(f"Intervalo: {INTERVALO_ENVIO}s")
    print("=" * 60)

    sensores = SimuladorSensores()

    while True:

        dados = sensores.gerar_leitura(
            CLIENTE_ID
        )

        print("\nNova leitura:")

        print(
            "Temperaturas:",
            dados["temperatura"]
        )

        print(
            "Umidade do solo:",
            dados["umidade_solo"]
        )

        print(
            "BME280:",
            dados["bme280"]
        )

        enviar_dados(dados)

        time.sleep(INTERVALO_ENVIO)


if __name__ == "__main__":
    main()